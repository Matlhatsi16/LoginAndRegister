/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginandregister;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;





import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 *
 * @author RC_Student_lab
 */

