
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginandregister;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import javax.swing.JOptionPane;
import static loginandregister.sendmessages.messArr;
import static loginandregister.sendmessages.messageCounter;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
/**
 *
 * @author RC_Student_lab
 */
public class Messages {
 
    
    public Boolean checkMessageID(){
     try {
            JSONParser parser = new JSONParser();
            JSONArray messageArray = (JSONArray) parser.parse(new FileReader("GoodChat_Messages.json"));

            Iterator<?> iterator = messageArray.iterator();

            while (iterator.hasNext()) {
                JSONObject messageObject = (JSONObject) iterator.next();


                String messageID = (String) messageObject.get("MessageID");

                // Check that it's exactly 10 digits
                if (messageID == null || !messageID.matches("\\d{10}")) {
                    return false; // invalid ID found
                }
            }

        } catch (Exception e) {
            System.out.println("Error reading or parsing file: " + e.getMessage());
            return false;
        }

        return true; // All IDs passed
    
        
    }
    
    public int checkRecipientCell(){
        int validCount = 0;

        try {
            JSONParser parser = new JSONParser();
            JSONArray messageArray = (JSONArray) parser.parse(new FileReader("GoodChat_Messages.json"));

            Iterator<?> iterator = messageArray.iterator();

            while (iterator.hasNext()) {
                JSONObject messageObject = (JSONObject) iterator.next();
                String recipient = (String) messageObject.get("Recipient");

                // Check: not null, starts with 0, exactly 10 digits
                if (recipient != null && recipient.matches("0\\d{9}")) {
                    validCount++;
                }
            }

        } catch (Exception e) {
            System.out.println("Error reading or parsing file: " + e.getMessage());
        }

        return validCount;

        
        
    }
    
    public String createMessageHash(String message, String id ){
        // Generate hash
            String[] words = message.split(" ");
            String hash = id.substring(0, 2) + ":" + messageCounter + ":" +
                    (words.length > 0 ? words[0].toUpperCase() : "") +
                    (words.length > 1 ? words[words.length - 1].toUpperCase() : "");
        return hash;
        
    }
   
    
    
    public void storeMessage(JSONArray mess, String path){
       try (FileWriter file = new FileWriter(path)) {
            file.write(mess.toJSONString());
            file.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving to file.");
        } 
        
       
        
    }
    
    public  String printMessages() {
    StringBuilder output = new StringBuilder();

        try {
            JSONParser parser = new JSONParser();
            JSONArray messageArray = (JSONArray) parser.parse(new FileReader("GoodChat_Messages.json"));

            Iterator<?> iterator = messageArray.iterator();

            while (iterator.hasNext()) {
                JSONObject messageObject = (JSONObject) iterator.next();
                String message = (String) messageObject.get("Message");
                output.append(message).append("\n");
            }

        } catch (Exception e) {
            System.out.println("Error reading JSON: " + e.getMessage());
        }

        return output.toString();

        
    
       
    }
    
    public int returnTotalMessages(){
        int total = 0;

        try {
            JSONParser parser = new JSONParser();
            JSONArray messageArray = (JSONArray) parser.parse(new FileReader("GoodChat_Messages.json"));

            total = messageArray.size();  // ✅ Get total number of elements

        } catch (Exception e) {
            System.out.println("Error reading JSON: " + e.getMessage());
        }

        return total;
       
        
        
    }
    public void storeMessage(){
        try (FileWriter file = new FileWriter("GoodChat_Messages.json")) {
            file.write(messArr.toJSONString());
            file.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving to file.");
        }
    }
}
