/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginandregister;
    
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import loginandregister.Messages;


import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;


public class sendmessages{

    static int messageCounter = 0;
    static JSONArray messagesList = new JSONArray();
    static JSONArray messArr = new JSONArray();
    static Messages mess = new Messages();
    
    
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to GoodChat!.");
         
        // Login
        String username = JOptionPane.showInputDialog("Please enter your username:(should be 5 letters long and should contain an underscore)");
        if(username!=null&&username.length()==5&&username.contains("_")){
            JOptionPane.showMessageDialog(null,"Username is accepted.");
            
        }else{
            JOptionPane.showMessageDialog(null,".Entered Username is invalid. It should be exactly 5 characters in length and should contain an underscore.");
        }
        
       
        
        
        String password = JOptionPane.showInputDialog("Please enter your password:");
        
        
        if(password!=null&&password.length()==8&&password.matches(".*[A-Z].*")&&password.matches(".*\\d.*")&&password.matches(".*[^a-zA-Z0-9].*")){
            
            JOptionPane.showMessageDialog(null, "Entered password is accepted");
            
        }else{
          JOptionPane.showMessageDialog(null, "Entered password is incorrect. It must contain 8 characters,be inclusive of a Capital letters,"+"\n"+"special character and a number...");
             System.exit(0);

        }
        
        
        JOptionPane.showConfirmDialog(null, "Welcome to GoodChat,"+username);
        
        
        String message = mess.printMessages();
        // Menu loop        // Menu loop
        while (true) {
            String[] options = {"1.Send Messages", "2.Show Sent Messages", "3.Exit"};
            int choice = JOptionPane.showOptionDialog(null, " Please choose an option:", "GoodChat Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            if (choice == 0) {
                sendMessages();
            } else if (choice == 1) {
                
                
                JOptionPane.showMessageDialog(null, "Message:."+ message);
            } else {
                break;
            }
        }
    }

    public static void sendMessages() {
        int numMessages = 0;
        try {
            String input = JOptionPane.showInputDialog("How many messages would you like to  send?");
            if (input == null) return;
            numMessages = Integer.parseInt(input);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Invalid number,please try again.");
            return;
        }

        for (int i = 0; i < numMessages; i++) {
            messageCounter++;
            String id = String.format("%010d", new Random().nextInt(1_000_000_000));
            
            String phone = JOptionPane.showInputDialog("Please provide recipient's phone number (10 digits):");
            if (phone == null) return;
            while (!phone.matches("\\d{10}")) {
                phone = JOptionPane.showInputDialog("Invalid phone number. Enter 10 digits:");
                if (phone == null) return;
            }

            String message = JOptionPane.showInputDialog("Enter message (Max 250 characters):");
            if (message == null) return;
            while (message.length() > 250) {
                message = JOptionPane.showInputDialog("Please enter a message of less than 250 characters:");
                if (message == null) return;
            }

            
            

            // Generate hash
            String hash = mess.createMessageHash(message, id);
            //String[] words = message.split(" ");
            //String hash = id.substring(0, 2) + ":" + messageCounter + ":" +
               //     (words.length > 0 ? words[0].toUpperCase() : "") +
                //    (words.length > 1 ? words[words.length - 1].toUpperCase() : "");
            //i++;
             JOptionPane.showMessageDialog(null, "Message stored.");

            // Store message
            JSONObject messageObj = new JSONObject();
            
            messageObj.put("MessageID", id);
            messageObj.put("MessageNumber", messageCounter);
            messageObj.put("Recipient", phone);
            messageObj.put("Message", message);
            messageObj.put("MessageHash", hash);

            String[] options = {"1.Send Message", "2.Discard Message", "3.Store to Send Later"};
            int action = JOptionPane.showOptionDialog(null, "What would you like to do with the message?:",
                    "Send Option", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[0]);

            if (action == 0 || action == 2) {
                messArr.add(messageObj);
            }

            // Optional: save after each message
            //saveMessagesToFile();
            mess.storeMessage(messArr, "GoodChat_Messages.json");
            
        }
    }

    @SuppressWarnings("unchecked")
    public static void saveMessagesToFile() {
        try (FileWriter file = new FileWriter("GoodChat_Messages.json")) {
            file.write(messArr.toJSONString());
            file.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving to file.");
        }
    }

    void setLocationRelativeTo(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void pack() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

        

    
    
        
    

  
    

    
